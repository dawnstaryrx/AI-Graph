<?php
/**
 * xz_aipt模块定义
 *
 * @author QQK05dzZDkNW
 * @url
 */
defined('IN_IA') or exit('Access Denied');

class Xz_aiptModule extends WeModule {



}